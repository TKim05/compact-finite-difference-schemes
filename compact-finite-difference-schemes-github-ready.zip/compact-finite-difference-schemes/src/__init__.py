"""Reproducibility tools for compact finite-difference research notebooks."""
