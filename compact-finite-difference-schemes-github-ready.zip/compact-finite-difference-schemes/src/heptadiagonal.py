"""Reimplementation of the user's heptadiagonal derivative validation notebook.

Important: boundary ghost derivatives are supplied analytically as part of this
controlled experiment; this is not a production boundary-condition solver.
The coefficients below are copied from the uploaded internship.ipynb notebook.
"""

import numpy as np

# Values originally hard-coded in internship.ipynb (rounded decimals).
A, B, C = 1.16098, 1.24087, 0.199073
ALPHA, BETA, GAMMA = 0.640794, 0.151692, 0.00797665


def test_function(x):
    return np.exp(-20 * x**2) * np.sin(50 * x)


def exact_derivative(x):
    return np.exp(-20 * x**2) * (50 * np.cos(50 * x) - 40 * x * np.sin(50 * x))


def solve_heptadiagonal(n=25):
    """Evaluate the original compact scheme on x in [0, 1], with n intervals.

    Returns arrays and errors. Exact outside-domain derivatives are intentionally
    supplied for ghost points, as in the original exploratory notebook.
    """
    if not isinstance(n, int) or n < 7:
        raise ValueError("n must be an integer >= 7")
    h = 1.0 / n
    x = np.linspace(0.0, 1.0, n + 1)
    extended_grid = np.arange(-3, n + 4) * h
    f_extended = test_function(extended_grid)
    d_extended = exact_derivative(extended_grid)

    rhs = np.zeros(n + 1)
    for i in range(n + 1):
        j = i + 3
        rhs[i] = (
            A * (f_extended[j + 1] - f_extended[j - 1]) / (2 * h)
            + B * (f_extended[j + 2] - f_extended[j - 2]) / (4 * h)
            + C * (f_extended[j + 3] - f_extended[j - 3]) / (6 * h)
        )

    matrix = np.zeros((n + 1, n + 1))
    couplings = {1: ALPHA, 2: BETA, 3: GAMMA}
    for i in range(n + 1):
        matrix[i, i] = 1.0
        for offset, coefficient in couplings.items():
            for j in (i - offset, i + offset):
                if 0 <= j <= n:
                    matrix[i, j] = coefficient
                else:
                    # In the original experiment, ghost *derivatives* are known.
                    rhs[i] -= coefficient * d_extended[j + 3]

    numerical = np.linalg.solve(matrix, rhs)
    exact = exact_derivative(x)
    error = numerical - exact
    return {
        "n": n,
        "x": x,
        "numerical": numerical,
        "exact": exact,
        "error": error,
        "max_abs_error": float(np.max(np.abs(error))),
        "rms_error": float(np.sqrt(np.mean(error**2))),
    }
