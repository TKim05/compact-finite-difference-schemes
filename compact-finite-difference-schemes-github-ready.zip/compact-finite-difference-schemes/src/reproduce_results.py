"""Generate figures and CSV for the original Python validation (run at repo root)."""

from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from .heptadiagonal import solve_heptadiagonal


def main():
    out = Path(__file__).resolve().parents[1] / "results"
    out.mkdir(exist_ok=True)
    results = [solve_heptadiagonal(n) for n in (20, 25, 50)]

    with (out / "heptadiagonal_errors.csv").open("w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["n_intervals", "max_abs_error", "rms_error"])
        writer.writerows((r["n"], r["max_abs_error"], r["rms_error"]) for r in results)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))
    for r in results:
        if r["n"] == 25:
            axes[0].plot(r["x"], r["exact"], label="Analytical derivative", linewidth=2)
            axes[0].plot(r["x"], r["numerical"], "--", label="Compact approximation")
    axes[0].set(xlabel="x", ylabel="Derivative", title="Derivative validation (n = 25)")
    axes[0].legend()
    axes[0].grid(alpha=0.3)
    axes[1].semilogy([r["n"] for r in results], [r["max_abs_error"] for r in results], "o-", label="Maximum absolute error")
    axes[1].semilogy([r["n"] for r in results], [r["rms_error"] for r in results], "s-", label="RMS error")
    axes[1].set(xlabel="Number of grid intervals (n)", ylabel="Error (log scale)", title="Recorded grid-resolution tests")
    axes[1].legend()
    axes[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out / "heptadiagonal_validation.png", dpi=175)
    plt.close(fig)
    for r in results:
        print(f'n={r["n"]}: max abs error={r["max_abs_error"]:.10g}, rms={r["rms_error"]:.10g}')

if __name__ == "__main__":
    main()
